from backend import backend

if __name__ == '__main__':
    backend.run(debug=True)